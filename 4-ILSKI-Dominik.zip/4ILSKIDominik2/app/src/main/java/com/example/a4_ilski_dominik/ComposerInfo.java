package com.example.a4_ilski_dominik;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class ComposerInfo extends AppCompatActivity {

    String[] musicalGenres = {"--Wybierz gatunek--", "Pop", "Jazz", "Indie", "Rock", "Lo-Fi"};
    String[] adoreLevel = {"marny", "niezły", "dobry", "bardzo dobry", "CZAAAAAAAD!"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_composer_info);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Informacje o wykonawcy");

        TextView name =  findViewById(R.id.textInfoName);
        TextView surname = findViewById(R.id.textInfoSurname);
        TextView nick = findViewById(R.id.textInfoNickname);
        TextView genre = findViewById(R.id.textInfoGenre);
        TextView adore = findViewById(R.id.textInfoAdore);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras != null)
            {




                name.setText(extras.getString("textInfoName"));
                surname.setText(extras.getString("textInfoSurname"));
                nick.setText(extras.getString("textInfoNickname"));
                genre.setText(musicalGenres[extras.getString("textInfoGenre").toCharArray()[1]-'0']);
                adore.setText(adoreLevel[extras.getString("textInfoAdore").toCharArray()[1]-'0']);

            }
        } else {
            name.setText((String) savedInstanceState.getSerializable("textInfoName"));
            surname.setText((String) savedInstanceState.getSerializable("textInfoName"));
            nick.setText((String) savedInstanceState.getSerializable("textInfoName"));
            genre.setText(musicalGenres[(int)savedInstanceState.getSerializable("textInfoName")]);
            adore.setText(adoreLevel[(int) savedInstanceState.getSerializable("textInfoName")]);

        }
    }

}
