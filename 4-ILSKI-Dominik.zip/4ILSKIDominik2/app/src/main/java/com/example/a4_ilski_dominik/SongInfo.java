package com.example.a4_ilski_dominik;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SongInfo extends AppCompatActivity {


    String[] adoreLevel = {"marny", "niezły", "dobry", "bardzo dobry", "CZAAAAAAAD!"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_song_info);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Informacje o utowrze");

        TextView name  = findViewById(R.id.textInfoName);
        TextView time  = findViewById(R.id.textInfoTime);
        TextView composer = findViewById(R.id.textInfoComposer);
        TextView adore = findViewById(R.id.textInfoAdore);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras != null)
            {




                name.setText(extras.getString("textInfoName"));
                time.setText(extras.getString("textInfoTime"));
                composer.setText(extras.getString("textInfoComposer"));
                adore.setText(adoreLevel[extras.getString("textInfoAdore").toCharArray()[1]-'0']);

            }
        } else {
            name.setText((String) savedInstanceState.getSerializable("textInfoName"));


            adore.setText(adoreLevel[(int) savedInstanceState.getSerializable("textInfoName")]);

        }



    }
}
