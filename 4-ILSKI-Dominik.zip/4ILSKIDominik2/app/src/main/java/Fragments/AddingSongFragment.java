package Fragments;


import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.a4_ilski_dominik.AppPreferences;
import com.example.a4_ilski_dominik.Composer;
import com.example.a4_ilski_dominik.R;
import com.example.a4_ilski_dominik.Song;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class AddingSongFragment extends Fragment {


    public AddingSongFragment() {
        // Required empty public constructor
    }
    SeekBar adoreSeekBar;
    AppPreferences _appPrefs;
    int adoreValue;
    ArrayList<String> composerList;
    EditText editTitle;
    EditText editTime;

    Spinner composerSpinner;


    SeekBar.OnSeekBarChangeListener adoreListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            adoreValue = adoreSeekBar.getProgress();
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_adding_song, container, false);
        _appPrefs = new AppPreferences(v.getContext());

        editTitle = v.findViewById(R.id.editTitle);
        editTime = v.findViewById(R.id.editTime);

        composerSpinner= v.findViewById(R.id.composerSpinner);
        adoreSeekBar = v.findViewById(R.id.adoreSeekBarSong);

        composerList = new ArrayList<>();

        for(Composer composer : _appPrefs.getComposerArray())
            composerList.add(composer.toString());
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), R.layout.spinner_item, composerList);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        composerSpinner.setAdapter(adapter);


        adoreSeekBar.setOnSeekBarChangeListener(adoreListener);



        return v;
    }

    private Song collectSongData()
    {
        String title = editTitle.getText().toString();
        int length =  !editTime.getText().toString().equals("") ? Integer.parseInt(editTime.getText().toString()) : 0;
        int composerPosition = composerSpinner.getSelectedItemPosition();
        int adore = adoreSeekBar.getProgress();
        String composerName = composerList.isEmpty() ? "-brak dancyh-" : composerList.get(composerPosition);
        return new Song(title,composerName,length,adore);
    }
    public void addSong(View view)
    {

        Song newSong = collectSongData();
        if(!checkCollectedData(newSong))
        {
            Toast.makeText(view.getContext(),
                    "Wypełnij Wszystkie Pola!",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<Song> newSongArray;
        newSongArray = _appPrefs.getSongArray();
        newSongArray.add(newSong);

        _appPrefs.saveSongArray(newSongArray);
        Toast.makeText(view.getContext(),
                "Dodano Utwór!",
                Toast.LENGTH_SHORT).show();
    }
    public void resetElementsSong(View view)
    {
        editTitle.setText("");
        editTime.setText("");
        composerSpinner.setSelection(0);
       adoreSeekBar.setProgress(0);
        Toast.makeText(view.getContext(),
                "Wyczyszczono Pola!",
                Toast.LENGTH_SHORT).show();
    }
    private boolean checkCollectedData(Song song)
    {
        if(song.getTitle().equals("")) return false;
        if(song.getComposer().equals("")) return false;
        if(song.getLengthInSeconds()==0) return false;

        return true;



    }
}
