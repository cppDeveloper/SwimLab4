package Fragments;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a4_ilski_dominik.AppPreferences;
import com.example.a4_ilski_dominik.Composer;
import com.example.a4_ilski_dominik.ComposerInfo;
import com.example.a4_ilski_dominik.CustomArrayAdapter;
import com.example.a4_ilski_dominik.MainActivity;
import com.example.a4_ilski_dominik.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComposersListFragment extends Fragment  {
    String[] musicalGenres = {"--Wybierz gatunek--", "Pop", "Jazz", "Indie", "Rock", "Lo-Fi"};
    String[] gradeLevel = {"marny", "niezły", "dobry", "bardzo dobry", "CZAAAAAAAD!"};
    public CustomArrayAdapter adapter;
    public ArrayList<Composer> composerArray;
    public ListView composerListView;
    View v;
   AppCompatActivity testA;
    public static ComposersListFragment newInstance() {
        return new ComposersListFragment();
    }

    AppPreferences _appPrefs;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

         v = inflater.inflate(R.layout.fragment_composers_list, container, false);
        _appPrefs = new AppPreferences(v.getContext());
        composerListView = v.findViewById(R.id.composerListView);
        composerArray = new ArrayList<>();
        composerArray = _appPrefs.getComposerArray();


        adapter = new CustomArrayAdapter(v.getContext(), composerArray);

        composerListView.setAdapter(adapter);
        composerListView.setOnItemClickListener( new OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<Composer> composerArray = _appPrefs.getComposerArray();
                Composer composer = composerArray.get(position);
                Intent intent = new Intent(view.getContext(), ComposerInfo.class);


                intent.putExtra("textInfoName"," " +composer.getName());
                intent.putExtra("textInfoSurname"," " +composer.getSurname());
                intent.putExtra("textInfoNickname"," " +composer.getNickname());
                intent.putExtra("textInfoGenre"," " + composer.getGenre());
                intent.putExtra("textInfoAdore"," " +composer.getAdoreRating());
                startActivity(intent);
            }

        });
        return v;
    }





    public void listRefresh() {
        composerArray = _appPrefs.getComposerArray();
        adapter = new CustomArrayAdapter(getContext(), composerArray);
        composerListView.setAdapter(adapter);

    }







}
