package Fragments;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.a4_ilski_dominik.AppPreferences;
import com.example.a4_ilski_dominik.Composer;
import com.example.a4_ilski_dominik.ComposerInfo;
import com.example.a4_ilski_dominik.CustomArrayAdapter;
import com.example.a4_ilski_dominik.R;
import com.example.a4_ilski_dominik.Song;
import com.example.a4_ilski_dominik.SongInfo;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class SongsListFragment extends Fragment {

    String[] musicalGenres = {"--Wybierz gatunek--", "Pop", "Jazz", "Indie", "Rock", "Lo-Fi"};
    String[] gradeLevel = {"marny", "niezły", "dobry", "bardzo dobry", "CZAAAAAAAD!"};
    public CustomArrayAdapter adapter;
    public ArrayList<Song> songArray;
    ListView songListView;
    AppPreferences _appPrefs;

    public static SongsListFragment newInstance() {
        return new SongsListFragment();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_songs_list, container, false);

        _appPrefs = new AppPreferences(v.getContext());
        songListView = v.findViewById(R.id.songListView);
        songArray = new ArrayList<>();
        songArray = _appPrefs.getSongArray();


        adapter = new CustomArrayAdapter(v.getContext(), songArray);
        songListView.setAdapter(adapter);
        songListView.setOnItemClickListener( new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ArrayList<Song> songArray = _appPrefs.getSongArray();
                ArrayList<Composer> composerArray = _appPrefs.getComposerArray();
                Composer composer = composerArray.get(position);
                Song song = songArray.get(position);
                Intent intent = new Intent(view.getContext(), SongInfo.class);


                intent.putExtra("textInfoName"," " +song.getTitle());
                intent.putExtra("textInfoTime", " " + song.getLengthInSeconds());
                intent.putExtra("textInfoComposer"," " + composer.getSurname());
                intent.putExtra("textInfoAdore"," " +song.getAdoreRating());
                startActivity(intent);
            }

        });


        return v;
    }
    public void listRefresh() {
        songArray = _appPrefs.getSongArray();
        adapter = new CustomArrayAdapter(getContext(), songArray);
        songListView.setAdapter(adapter);

    }

    public class CustomArrayAdapter extends ArrayAdapter {
        Context context;
        ArrayList<Song> listOfComposers;
        LayoutInflater layoutInflater;
        Activity activity;

        Boolean isFirst;

        AppPreferences _appPrefs;

        String[] musicalGenres = {"--Wybierz gatunek--", "Pop", "Jazz", "Indie", "Rock", "Lo-Fi"};
        String[] gradeLevel = {"marny", "niezły", "dobry", "bardzo dobry", "CZAAAAAAAD!"};

        public CustomArrayAdapter(Context context, ArrayList<Song> listOfComposers) {
            super(context,R.layout.list_row, listOfComposers);
            this.context = context;
            this.activity =activity;
            this.listOfComposers = listOfComposers;
            layoutInflater = LayoutInflater.from(context);
            isFirst=true;
            _appPrefs = new AppPreferences(context);

        }


        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Song song;
            View v = convertView;
            if(convertView==null)
            {
                if(_appPrefs.getSongArray().isEmpty())
                    return layoutInflater.inflate(R.layout.empty_composer, parent, false);
                else
                    v =  layoutInflater.inflate(R.layout.list_row_song, parent,false);
            }



            TextView title= v.findViewById(R.id.row_tv1);
            //TextView  musicGenre= v.findViewById(R.id.row_tv2);
            TextView  grade= v.findViewById(R.id.textGrade);

            song= listOfComposers.get(position);

            title.setText(song.getTitle());

            grade.setText(gradeLevel[song.getAdoreRating()]);




            return v;
        }
    }
}
