package Fragments;


import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.a4_ilski_dominik.AppPreferences;
import com.example.a4_ilski_dominik.Composer;
import com.example.a4_ilski_dominik.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */


public class AddingCompFragment extends Fragment {

    String[] musicalGenres = {"--Wybierz gatunek--", "Pop", "Jazz", "Indie", "Rock", "Lo-Fi"};
    SeekBar adoreSeekBar;
    AppPreferences _appPrefs;
    int adoreValue;

    EditText textName;
    EditText textSurname;
    EditText textTitle;
    Spinner genreSpinner;


    SeekBar.OnSeekBarChangeListener adoreListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            adoreValue = adoreSeekBar.getProgress();
        }
    };

    public AddingCompFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_adding_comp, container, false);
        _appPrefs = new AppPreferences(v.getContext());

        textName = v.findViewById(R.id.editTextName);
        textSurname = v.findViewById(R.id.editTextSurname);
        textTitle = v.findViewById(R.id.editTextTitle);
        genreSpinner= v.findViewById(R.id.genreSpinner);
        adoreSeekBar = v.findViewById(R.id.seekBar);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), R.layout.spinner_item, musicalGenres);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        genreSpinner.setAdapter(adapter);


        adoreSeekBar.setOnSeekBarChangeListener(adoreListener);



        return v;

    }



    private boolean checkCollectedData(Composer composer)
    {
        if(composer.getName().equals("")) return false;
        if(composer.getSurname().equals("")) return false;
        if(composer.getNickname().equals("")) return false;
        if(composer.getGenre()==0) return false;

        return true;



    }
    public void addComposer(View view)
    {

        Composer newComposer = collectComposerData();
        if(!checkCollectedData(newComposer))
        {
            Toast.makeText(view.getContext(),
                    "Wypełnij Wszystkie Pola!",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<Composer> newComposerArray;
        newComposerArray = _appPrefs.getComposerArray();
        newComposerArray.add(newComposer);

        _appPrefs.saveComposerArray(newComposerArray);
        Toast.makeText(view.getContext(),
                "Dodano Wykonawcę!",
                Toast.LENGTH_SHORT).show();



    }
    private Composer collectComposerData()
    {
        String name = textName.getText().toString();
        String surname = textSurname.getText().toString();
        String title = textTitle.getText().toString();
        int genre = genreSpinner.getSelectedItemPosition();
        int adore = adoreSeekBar.getProgress();
        return new Composer(name,surname,title,genre,adore);
    }
    public void resetElements(View view)
    {
        textName.setText("");
        textSurname.setText("");
        textTitle.setText("");
        genreSpinner.setSelection(0);
        adoreSeekBar.setProgress(0);
        Toast.makeText(view.getContext(),
                "Wyczyszczono Pola!",
                Toast.LENGTH_SHORT).show();
    }



}
